--
-- (C) 2019 - ntop.org
--
dirs = ntop.getDirs()
package.path = dirs.installdir .. "/scripts/lua/?.lua;" .. package.path
if((dirs.scriptdir ~= nil) and (dirs.scriptdir ~= "")) then package.path = dirs.scriptdir .. "/lua/modules/?.lua;" .. package.path end
ignore_post_payload_parse = 1

local dialogflow = require "nAssistant/dialogflow_APIv2"
local handlers = require "nAssistant/handlers"

local user_request, ntop_response = dialogflow.receive(), {}
------------------------
------------------------

if  user_request.queryResult.intent.displayName == "ask_for_host_info - fallback" then
    ntop_response = handlers.host_info(user_request)

elseif  user_request.queryResult.intent.displayName == "ask_for_host_info - fallback - more" then
    ntop_response = handlers.host_info_more(user_request)

------------------------
elseif  user_request.queryResult.intent.displayName == "if_active_flow_top_application" then
    ntop_response = handlers.if_active_flow_top_application(user_request)

elseif  user_request.queryResult.intent.displayName == "if_active_flow_top_categories"  then
    ntop_response = handlers.if_active_flow_top_categories(user_request)

------------------------
elseif  user_request.queryResult.intent.displayName == "who_is - categories" then
    ntop_response = handlers.who_is_categories(user_request)

elseif  user_request.queryResult.intent.displayName == "who_is - protocols"  then
    ntop_response = handlers.who_is_protocols(user_request)

------------------------
elseif  user_request.queryResult.intent.displayName == "who_is - categories - fallback" then
    ntop_response = handlers.host_info(user_request)

elseif  user_request.queryResult.intent.displayName == "who_is - protocols - fallback" then
    ntop_response = handlers.host_info(user_request) 

------------------------
elseif  user_request.queryResult.intent.displayName == "get_security_info" then
    ntop_response = handlers.get_security_info(user_request)

elseif  user_request.queryResult.intent.displayName == "get_security_info - fallback" then
    ntop_response =handlers.host_info(user_request) 

elseif  user_request.queryResult.intent.displayName == "get_security_info - fallback - more" then
    ntop_response = handlers.host_info_more(user_request)

------------------------
elseif  user_request.queryResult.intent.displayName == "get_suspected_host_info" then
    ntop_response = handlers.get_most_suspected_host_info(user_request)

elseif  user_request.queryResult.intent.displayName == "get_host_misbehaving_flows_info" then
    ntop_response = handlers.get_host_misbehaving_flows_info(user_request) 

else ntop_response = dialogflow.send("Sorry, but I didn't understand, can you repeat please?") 
end

dialogflow.send(
    ntop_response.speech_text,
    ntop_response.display_text,
    ntop_response.suggestions,
    ntop_response.card
)
